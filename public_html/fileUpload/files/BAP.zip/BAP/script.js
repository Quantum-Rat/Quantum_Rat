const buy = document.querySelector("#buy")
const sell = document.querySelector("#sell")
const buttons = document.querySelectorAll(".functions-buttons")
const graphic = document.querySelector(".graphic")
const btcList = document.querySelector(".item-list")
const money = document.querySelector(".money-txt")
const alertDOM = document.querySelector(".alert")
const menu = document.querySelector(".menu")
const moneyAddBtn = document.querySelector(".money-btn")

const menuCloseBtn = document.querySelector(".menu-close-btn")
const moneyAmount = document.querySelector(".menu-card-input2")
const menuConfirmBtn = document.querySelector(".menu-btn")
const menuCardInput = document.querySelectorAll(".menu-card-input")

const menu2 = document.querySelector(".menu2")
const menu2CardInput = document.querySelector(".menu2-card-input")
const menu2ConfirmBtn = document.querySelector(".menu2-btn")
const menu2CloseBtn = document.querySelector(".menu2-close-btn")


let balance = 0
let click = true
let trade = false
let buyCheck = false
let sellCheck = false

buy.addEventListener("click", () => {
    menu2.classList.remove("display")
    buyCheck = true
}) 

sell.addEventListener("click", () => {
    menu2.classList.remove("display")
    sellCheck = true
}) 


menuConfirmBtn.addEventListener("click", () => {
    let empty = true
    menuCardInput.forEach(input => {
        if(input.value == "") {
            empty = false
        }
    })

    if(empty) {
        balance += Number(moneyAmount.value)
        money.innerHTML = `Bakiye: $${balance}`
        menu.classList.add("display")
    }
})


moneyAddBtn.addEventListener("click", () => {
    menu.classList.remove("display")
})

menuCloseBtn.addEventListener("click", () => {
    menu.classList.add("display")
})

menu2ConfirmBtn.addEventListener("click", () => {
    if(menu2CardInput.value != "") {
        balance -= Number(menu2CardInput.value)
        money.innerHTML = `Bakiye: $${balance}`
        btcList.innerHTML += `<div>${60000 / Number(moneyAmount.value)} Adet BTC</div>`
        menu2.classList.add("display")
        trade = true

        if(sellCheck && click) {
            btcList.innerHTML += `<div>${60000 / Number(moneyAmount.value)}</div>`
            balance -= Number(moneyAmount.value)
            click = false
            setTimeout(() => {
                graphic.style.backgroundImage = "url(yukselis.png)"
                money.innerHTML = `Bakiye: $${balance}`
                buttons.forEach(btn => {
                    btn.classList.add("btn-transparent")
                })
                alertDOM.classList.remove("display")
            }, 1000)
        }

        if(buyCheck && click) {
            btcList.innerHTML += `<div>${60000 / Number(moneyAmount.value)}</div>`
            balance -= Number(moneyAmount.value)
            click = false
            setTimeout(() => {
                graphic.style.backgroundImage = "url(dusus.png)"
                money.innerHTML = `Bakiye: $${balance}`
                buttons.forEach(btn => {
                    btn.classList.add("btn-transparent")
                })
                alertDOM.classList.remove("display")
            }, 1000)
        }

    }
})

menu2CloseBtn.addEventListener("click", () => {
    menu2.classList.add("display")
    buyCheck = false
    sellCheck = false
})