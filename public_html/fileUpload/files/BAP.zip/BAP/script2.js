const buy = document.querySelector("#buy")
const sell = document.querySelector("#sell")
const buttons = document.querySelectorAll(".functions-buttons")
const graphic = document.querySelector(".graphic")
const btcList = document.querySelector(".item-list")
const money = document.querySelector(".money-txt")
const alertDOM = document.querySelector(".alert")
const menu = document.querySelector(".menu")
const moneyAddBtn = document.querySelector(".money-btn")
const menuCloseBtn = document.querySelector(".menu-close-btn")
const moneyAmount = document.querySelector(".menu-card-input2")
const menuConfirmBtn = document.querySelector(".menu-btn")
const menuCardInput = document.querySelectorAll(".menu-card-input")
// const menu2 = document.querySelector(".menu2")
// const menu2CardInput = document.querySelector(".menu2-card-input")
// const menu2ConfirmBtn = document.querySelector(".menu2-btn")
// const menu2CloseBtn = document.querySelector(".menu2-close-btn")
const emircakmakContainer = document.querySelector(".emircakmak-container")
const emircakmakContainer2 = document.querySelector(".emircakmak-container2")
const emircakmak = document.querySelector(".emircakmak")
const emircakmakBottomBtn = document.querySelector(".emircakmak-chat-bottom-btn")
const emircakmakMid = document.querySelector(".emircakmak-chat-mid")
const emircakmakLink = document.querySelector(".emircakmak-link")
const emircakmakChat = document.querySelector(".emircakmak-chat")
const jumpscare = document.querySelector(".emircakmak-jumpscare")


let balance = 0
let click = true

buy.addEventListener("click", () => {
    if(click && Number(moneyAmount.value) > 0) {
        btcList.innerHTML += `<div>${(Number(moneyAmount.value) / 60000)} Adet BTC</div>`
        balance -= Number(moneyAmount.value)
        click = false
        money.innerHTML = `Bakiye: $0`
        moneyAddBtn.classList.add("display")
        setTimeout(() => {
            graphic.style.backgroundImage = "url(dusus.png)"
            buttons.forEach(btn => {
                btn.classList.add("btn-transparent")
            })
            alertDOM.classList.remove("display")
            emircakmakContainer.classList.remove("display")
            
        }, 1000)
    }
}) 

sell.addEventListener("click", () => {
    if(click && Number(moneyAmount.value) > 0) {
        btcList.innerHTML += `<div>${(Number(moneyAmount.value) / 60000)} Adet BTC</div>`
        balance -= Number(moneyAmount.value)
        click = false
        money.innerHTML = `Bakiye: $0`
        moneyAddBtn.classList.add("display")
        setTimeout(() => {
            graphic.style.backgroundImage = "url(yukselis.png)"
            buttons.forEach(btn => {
                btn.classList.add("btn-transparent")
            })
            alertDOM.classList.remove("display")
            emircakmakContainer.classList.remove("display")
        }, 1000)
    }
}) 


menuConfirmBtn.addEventListener("click", () => {
    let empty = true
    menuCardInput.forEach(input => {
        if(input.value == "") {
            empty = false
        }
    })

    if(empty) {
        balance += Number(moneyAmount.value)
        money.innerHTML = `Bakiye: $${balance}`
        menu.classList.add("display")
    }
})


moneyAddBtn.addEventListener("click", () => {
    menu.classList.remove("display")
})

menuCloseBtn.addEventListener("click", () => {
    menu.classList.add("display")
})

emircakmakContainer.addEventListener("click", () => {
    emircakmakContainer2.classList.remove("display")
})

emircakmakLink.addEventListener("click", () => {
    emircakmakChat.classList.remove("display")
})

let emircakmakBottomBtnClickNumber = 0

emircakmakBottomBtn.addEventListener("click", () => {
    if(emircakmakBottomBtnClickNumber == 0) {
        emircakmakBottomBtnClickNumber++
        emircakmakMid.innerHTML += `
    <div class="emircakmak-msgbox msgbox-left">
                    <span class="emircakmak-msgbox-name">Kullanıcı</span>
                    <span class="emircakmak-msgbox-txt">Paramı Geri İstiyorum</span>
                </div>
    `
    
    setTimeout(() => {
        emircakmakMid.innerHTML += `
        <div class="emircakmak-msgbox">
                    <span class="emircakmak-msgbox-name">Pezenvenkemircakmak</span>
                    <span class="emircakmak-msgbox-txt">أنا أحب بطال ونمنا مع بطال</span>
                </div>
        `
        emircakmakBottomBtn.innerHTML = "PARAMI GERİ VER!!"
        emircakmakBottomBtn.classList.add("btnAnimation")
    }, 1000)
    } else if(emircakmakBottomBtnClickNumber == 1) {
        setTimeout(() => {
            jumpscare.classList.remove("display")
        }, 500)
    }

    
})