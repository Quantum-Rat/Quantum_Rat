const menuFixed = document.querySelector(".menu-fixed")
const menu = document.querySelector(".menu")
const menuLines = document.querySelector(".menu-lines")
const menuContentColumn = document.querySelectorAll(".menu-content-column")
const menuContentColumn0 = document.querySelectorAll(".menu-column0")
const menuContentColumn00 = document.querySelectorAll(".menu-column00")

let hover = true
let clickQueue = 1

menuLines.addEventListener("click", () => {
    if(hover && clickQueue == 1) {
        menu.classList.add("menu-width")
        setTimeout(() => {
            menuFixed.classList.add("menu-height")
        }, 700)
        setTimeout(() => {
            void menuContentColumn.offsetWidth;
            menuContentColumn0.forEach(column => {
                column.classList.remove("menu-column3")
                column.classList.add("menu-column1")
            })
            menuContentColumn00.forEach(column => {
                column.classList.remove("menu-column4")
                column.classList.add("menu-column2")
            })
            hover = true
            clickQueue = 2
        }, 700)
    }

    if(hover && clickQueue == 2) {
        void menuContentColumn.offsetWidth;
        menuContentColumn0.forEach(column => {
            column.classList.add("menu-column3")
            column.classList.remove("menu-column1")
        })
        menuContentColumn00.forEach(column => {
            column.classList.add("menu-column4")
            column.classList.remove("menu-column2")
        })
        setTimeout(() => {
            menuFixed.classList.remove("menu-height")
        }, 500)
        setTimeout(() => {
            menu.classList.remove("menu-width")
            hover = true
            clickQueue = 1
        }, 1200)
        
    }
    hover = false
})

